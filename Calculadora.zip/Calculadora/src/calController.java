import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;


public class calController {
    private int total= 0;
    private String numero="";
    private String Operando1="";
    private String operador = "";

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField resultadoTxt;

    @FXML
    private Button btn7;

    @FXML
    private Button btn8;

    @FXML
    private Button btn9;

    @FXML
    private Button btnDiv;

    @FXML
    private Button btn4;

    @FXML
    private Button btn5;

    @FXML
    private Button btn6;

    @FXML
    private Button btnMulti;

    @FXML
    private Button btn1;

    @FXML
    private Button btn2;

    @FXML
    private Button btn3;

    @FXML
    private Button btnMenos;

    @FXML
    private Button btnC;

    @FXML
    private Button btn0;

    @FXML
    private Button btnIgual;

    @FXML
    private Button btnSuma;

    @FXML
    void initialize() {

    }

    @FXML
    void addNumero(ActionEvent event) {
        Node nodo = (Node) event.getSource();
        String nodoId = nodo.getId();
        String digito = "";
        switch(nodoId) {
            case "btn0":
                digito= "0";
                break;
            case "btn1":
                digito= "1";
                break;
            case "btn2":
                digito= "2";
                break;
            case "btn3":
                digito= "3";
                break;
            case "btn4":
                digito= "4";
                break;
            case "btn5":
                digito= "5";
                break;
            case "btn6":
                digito= "6";
                break;
            case "btn7":
                digito= "7";
                break;
            case "btn8":
                digito= "8";
                break;
            case "btn9":
                digito= "9";
                break;
            case "btnC":
                digito= "C";
                break;
            default :
                resultadoTxt.setText("0");
                break;
        }
        if (digito.equals("C")) {
            numero= "";
        } else {
            numero += digito;
        }
        resultadoTxt.setText(numero);
        if (!numero.equals("")) System.out.println(Integer.parseInt(numero));
    }

    @FXML
    void selectOp(ActionEvent event) {
        Node nodo = (Node) event.getSource();
        String nodoId = nodo.getId();     
        switch(nodoId) {
            case "btnSuma":
                operador= "+";
                break;
            case "btnMenos":
                operador= "-";
                break;
            case "btnMulti":
                operador= "*";
                break;
            case "btnDiv":
                operador= "/";
                break;
            default :
                break;
        }
        Operando1= numero;
        numero="";
        System.out.println(Operando1);
    }

    @FXML
    void resultOp() {
        switch(operador){
            case "+" :
                total = Integer.parseInt(Operando1) + Integer.parseInt(numero);
                break;
            case "-" :
                total = Integer.parseInt(Operando1) - Integer.parseInt(numero);
                break;
            case "*" :
                total = Integer.parseInt(Operando1) * Integer.parseInt(numero);
                break;
            case "/" :
                total = Integer.parseInt(Operando1) / Integer.parseInt(numero);
                break;
        }
        Operando1="";
        numero="";
        resultadoTxt.setText(Integer.toString(total));
    }
}